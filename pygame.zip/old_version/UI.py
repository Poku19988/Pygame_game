import pygame
pink = (205,92,0)
black = (0,0,0)
class UI:
	def __init__(self):
		self.red = (255,0,0)

		self.display_surface = pygame.display.get_surface()
		self.font = pygame.font.Font(None,23)

		# bar setup 
		self.health_bar_rect = pygame.Rect(10,10,80,40) #healthbar width and height
		self.energy_bar_rect = pygame.Rect(10,34,40,20) 
		


	def show_bar(self,current,max_amount,bg_rect,color):
		# draw bg 
		pygame.draw.rect(self.display_surface,self.red,bg_rect)

		# converting stat to pixel
		ratio = current / max_amount
		current_width = bg_rect.width * ratio
		current_rect = bg_rect.copy()
		current_rect.width = current_width

		# drawing the bar
		pygame.draw.rect(self.display_surface,color,current_rect)
		pygame.draw.rect(self.display_surface,pink,bg_rect,3)

	def show_exp(self,exp):
		text_surf = self.font.render(str(int(exp)),False,black)
		x = self.display_surface.get_size()[0] - 20
		y = self.display_surface.get_size()[1] - 20
		text_rect = text_surf.get_rect(bottomright = (x,y))

		pygame.draw.rect(self.display_surface,self.red,text_rect.inflate(20,20))
		self.display_surface.blit(text_surf,text_rect)
		pygame.draw.rect(self.display_surface,pink,text_rect.inflate(20,20),3)
