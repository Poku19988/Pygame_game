import pygame
frames = []
frames_d = []
frames_a = []
enemy_frames_d = []
enemy_spritesheet = pygame.image.load('Enemy_spritesheet.png')
spritesheet = pygame.image.load('char_spritesheet.png').convert_alpha()
for i in range(13) :
    x = i*32
    y = 0
    frame_rect = pygame.Rect(x, y , 32,32)
    frames.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
for i in range (10) :
    x = i*32
    y = 64
    frame_rect = pygame.Rect(x,y,32,32)
    frames_d.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
    frames_a.append(pygame.transform.flip((pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40))),True,False) )
for j in range(-1,1) :    
    for i in range(6) :
        x = i*64
        y = 192+j*64
        frame_rect = pygame.Rect(x,y,64,64)
        enemy_frames_d.append(pygame.transform.scale((enemy_spritesheet.subsurface(frame_rect)),(40,40)))
class Bloackedareas(pygame.sprite.Sprite) :
     def __init__(self, x, y, width, height):
        super().__init__()
        self.image = pygame.Surface([width, height])
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
class Enemy (pygame.sprite.Sprite) :
    def __init__(self,x,y) :
        super().__init__()
        self.frames = enemy_frames_d
        self.frames_d = frames_d
        self.image = self.frames[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.current_frame = 0
        self.frametimer = 0
        self.frame_delay = 12
        print(len(enemy_frames_d))
        self.current = 0
        self.d = -10
    def upadate(self) :
        self.frametimer = pygame.time.get_ticks()
        if self.frametimer - self.current >= self.frame_delay :
            self.current_frame = (self.current_frame+1) % 12
            self.image = self.frames[self.current_frame]
            self.frame_timer = 0
        self.current = pygame.time.get_ticks()
        self.rect.x += self.d
        if self.rect.x <= 80 :
            self.d=self.d*(-1)
        if self.rect.x >= 280 :
            self.d=self.d*(-1)
enemy_1 = Enemy(240,160)
enemy_spritesheet = pygame.image.load('Enemy_spritesheet.png')
enemy_frames_d = []
blocked_area1 = Bloackedareas(80,0,480,40)
blocked_areas = pygame.sprite.Group()
blocked_areas_enemy=pygame.sprite.Group()
enemy_1_bloacked = Bloackedareas(enemy_1.rect.x,enemy_1.rect.y,40,40)
blocked_areas_enemy.add(enemy_1_bloacked)
