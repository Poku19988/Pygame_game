import pygame,random
pygame.init()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('Legend of theodora')
char = pygame.image.load('coconut.png')
spritesheet = pygame.image.load('char_spritesheet.png').convert_alpha()
background = pygame.image.load('map2.png')
enemy_image = 'coconut.png'
enemy_image2 = 'coconut.png'
run = True
white = (255,255,255)
black = (0,0,0)
frames = []
for i in range(5) :
    x = i*32
    y = 0
    frame_rect = pygame.Rect(x, y , 32,32)
    frames.append(spritesheet.subsurface(frame_rect))
class Player(pygame.sprite.Sprite) :
    def __init__(self,x,y) :
        super().__init__()
        self.frames = frames
        self.image = self.frames[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.current_frame = 0
        self.frametimer = 0
        self.frame_delay = 10
    def upadate(self) :
        self.frametimer += 1
        if self.frametimer >= self.frame_delay :
            self.current_frame = (self.current_frame+1) % len(self.frames)
            self.image = self.frames[self.current_frame]
            self.frame_timer = 0
clock = pygame.time.Clock()
player = Player(0,0)
while run == True  :
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            run = False
    player.upadate()
    screen.blit(background,(0,0))
    screen.blit(player.image,player.rect)
    clock.tick(60)
    
 