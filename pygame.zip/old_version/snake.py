import pygame
pygame.init()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('reun')
char = pygame.image.load('coconut.png')
char_pos = 600
run = True
white = (255,255,255)
black = (0,0,0)
oop = (222,22,122)
pygame.display.flip()
screen.blit(char,(char_pos,250))
screen.fill(black)
block_speed= 40
clock = pygame.time.Clock()
pygame.display.update()
for x in range(0, 800, 40):
    for y in range(0,800, 40):
        rect = pygame.Rect(x, y, 40, 40)
        pygame.draw.rect(screen, white, rect)
        pygame.draw.rect(screen, black, rect, 1)
init_pos = (0,0)
image_rect = char.get_rect()
while run == True :
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            break
        elif event.type == pygame.KEYDOWN :
            if event.key == pygame.K_d and init_pos[0]<740:
                    screen.blit(char,(init_pos[0]+40,init_pos[1]))
                    rect = pygame.Rect(init_pos[0],init_pos[1], 40, 40)
                    pygame.draw.rect(screen, white, rect)
                    pygame.draw.rect(screen, black, rect, 1)
                    init_pos = (init_pos[0]+40,init_pos[1])
            if event.key ==pygame.K_s and init_pos[1]<740 :
                screen.blit(char,(init_pos[0],init_pos[1]+40))
                rect = pygame.Rect(init_pos[0],init_pos[1], 40, 40)
                pygame.draw.rect(screen, white, rect)
                pygame.draw.rect(screen, black, rect, 1)
                init_pos = (init_pos[0],init_pos[1]+40)
            if event.key ==pygame.K_a and init_pos[0]>=40 :
                screen.blit(char,(init_pos[0]-40,init_pos[1]))
                rect = pygame.Rect(init_pos[0],init_pos[1], 40, 40)
                pygame.draw.rect(screen, white, rect)
                pygame.draw.rect(screen, black, rect, 1)
                init_pos = (init_pos[0]-40,init_pos[1])
        else :
                screen.blit(char,(init_pos[0],init_pos[1]))
        
    clock.tick(30)

    

    
    
    