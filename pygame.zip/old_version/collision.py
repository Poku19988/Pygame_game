import pygame

# Initialize Pygame
pygame.init()

# Set up the game window
screen = pygame.display.set_mode((640, 480))
pygame.display.set_caption("Ball Physics")

# Define the ball's position, velocity, and acceleration
ball_pos = [100, 100]
ball_vel = [0, 0]
ball_acc = [0, 0.1]

# Define the ground object
ground_rect = pygame.Rect(0, 400, 640, 80)

# Set up the game loop
clock = pygame.time.Clock()
game_running = True
while game_running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_running = False

    # Update the ball's position and velocity
    ball_vel[0] += ball_acc[0]
    ball_vel[1] += ball_acc[1]
    ball_pos[0] += ball_vel[0]
    ball_pos[1] += ball_vel[1]

    # Check for collisions with the ground
    ball_rect = pygame.Rect(ball_pos[0] - 10, ball_pos[1] - 10, 20, 20)
    if ball_rect.colliderect(ground_rect):
        ball_pos[1] = ground_rect.top + 10
        ball_vel[1] = -ball_vel[1] * 0.8

    # Draw the ball and ground on the screen
    screen.fill((0, 0, 0))
    pygame.draw.circle(screen, (255, 255, 255), ball_pos, 10)
    pygame.draw.rect(screen, (0, 255, 0), ground_rect)

    # Flip the display
    pygame.display.flip()

    # Set the game clock
    clock.tick(60)

# Quit Pygame
pygame.quit()