import pygame,random
pygame.init()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('Legend of theodora')
char = pygame.image.load('coconut.png')
background = pygame.image.load('map2.png')
enemy_image = 'coconut.png'
enemy_image2 = 'coconut.png'
char_pos = 600
run = True
white = (255,255,255)
black = (0,0,0)
oop = (222,22,122)
pygame.display.flip()
screen.blit(char,(char_pos,250))
class Player :
    def __init__(self,Level,Experience,Health) :
        self.Health = Health
        self.Level = Level 
        self.Experience = Experience
class Healthbar :
    def __init__(self,Health,screen):
        self.Health = Health
        self.screen = screen
        self.maxHealth = 80
    def draw (self) :
        self.rect = pygame.Rect(600,40,160,40)
        self.rect2 = pygame.Rect(600,40,160,(self.Health/self.maxHealth)*self.Health)
        pygame.draw.rect(self.screen,(52, 64, 235),self.rect)          
        pygame.draw.rect(self.screen,(240, 0, 24),self.rect2)
class Movement :  
    def __init__(self,screen,char,c,backgorund) :
        self.screen =screen
        self.char = char
        self.init_pos = (0,0)
        self.c =c
        self.background = backgorund
    def move_right(self) :
        if self.init_pos[0] <760 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (0,0,0), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            screen.blit(self.background,(0,0))
            self.init_pos =(self.init_pos[0]+40,self.init_pos[1])
            self.update_screen()
    def move_left(self) :
        if self.init_pos[0] >=40 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen,(0,0,0), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            screen.blit(self.background,(0,0))
            self.init_pos =(self.init_pos[0]-40,self.init_pos[1])
            self.update_screen()
    def move_down(self) :
         if self.init_pos[1] < 740 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (0,0,0), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            screen.blit(self.background,(0,0))
            self.init_pos =(self.init_pos[0],self.init_pos[1]+40)
            self.update_screen()
    def move_up(self) :
        if self.init_pos[1] >= 40 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (0,0,0), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            screen.blit(self.background,(0,0))
            self.init_pos =(self.init_pos[0],self.init_pos[1]-40)
            self.update_screen()
    def update_screen(self) :
        self.screen.blit(self.char,self.init_pos)  
class Enemy :
    def __init__(self,Health,image,pos_x,pos_y,screen) :
        self.Health = Health
        self.image = image
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.screen = screen
    def update (self) :
        self.screen.blit(self.image,(self.pos_x,self.pos_y))
    def return_coordinates_x (self) :
        return self.pos_x
    def return_coordinates_y (self) :
        return self.pos_y
class collision :
    def __init__(self,pos1_x,pos1_y,pos2_x,pos2_y) :
        self.pos1_x = pos1_x
        self.pos1_y = pos1_y
        self.pos2_x = pos2_x
        self.pos2_y = pos2_y
    def check(self) :
        if self.pos1_x ==self.pos2_x or self.pos2_x == self.pos2_y :
            return True
        else :
         return False 
c = True
enemies = pygame.sprite.Group()
enemies.add()
b = []

for x in range (7) :
    if x>3 :
        new_enemy = Enemy(80,char,random.randint(0,800),random.randint(0,800),screen)
        b.append(new_enemy)
    else :
        new_enemy = Enemy(160,char,random.randint(0,800),random.randint(0,800),screen)
        b.append(new_enemy)
health = Healthbar(90,screen)
movement = Movement(screen,char,c,background)  
movement_enemy = Movement(screen,char,c,background) 
while run == True  :
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            run = False
        elif event.type == pygame.KEYDOWN :
            if event.key == pygame.K_d :
                screen.blit(background,(0,0)) 
                movement.move_right()
                movement.c = False
            if event.key == pygame.K_a :
                screen.blit(background,(0,0)) 
                movement.move_left()
                movement.c = False
            if event.key == pygame.K_s :
                screen.blit(background,(0,0))
                movement.move_down()
                movement.c = False
            if event.key == pygame.K_w :
                screen.blit(background,(0,0))
                movement.move_up()
                movement.c =False
        elif movement.c==True:
                screen.blit(background,(0,0))
                screen.blit(char,(0,0))
    for i in range(7) :
        b[i].update()
        Coll=collision(b[i].return_coordinates_x(),b[i].return_coordinates_y,movement.init_pos[0],movement.init_pos[1])
        if Coll.check() :
            print('yep')
    health.draw()
   

