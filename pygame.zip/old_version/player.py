import pygame
from enemy import blocked_areas_enemy
from enemy import blocked_areas
frames = []
frames_d = []
frames_a = []
spritesheet = pygame.image.load('char_spritesheet.png').convert_alpha()
for i in range(13) :
    x = i*32
    y = 0
    frame_rect = pygame.Rect(x, y , 32,32)
    frames.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
for i in range (10) :
    x = i*32
    y = 64
    frame_rect = pygame.Rect(x,y,32,32)
    frames_d.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
    frames_a.append(pygame.transform.flip((pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40))),True,False) )
class Player(pygame.sprite.Sprite) :      #Player class
    def __init__(self,x,y,current_health) :
        super().__init__()
        self.Health = 90
        self.frames = frames
        self.frames_d = frames_d
        self.frames_a = frames_a
        self.image = self.frames[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.current_frame = 0
        self.frametimer = 0
        self.frame_delay = 18
        self.current = 0
        self.current_health = current_health
    def upadate(self) :
        self.frametimer = pygame.time.get_ticks()
        if self.frametimer - self.current >= self.frame_delay :
            self.current_frame = (self.current_frame+1) % len(self.frames)
            self.image = self.frames[self.current_frame]
            self.frame_timer = 0
        self.current = pygame.time.get_ticks()
        
    def move_right(self) :
        if self.rect.x <=740  :
            self.rect.x +=40
        if pygame.sprite.spritecollide(self,blocked_areas,False) :
            self.rect.x -=40
        if pygame.sprite.spritecollide(self,blocked_areas_enemy,True) :
            self.current_health -=10
            print(self.current_health)       
    def move_left(self) :
        if self.rect.x >= 40 :
            self.rect.x -=40
            print(self.current_health)                   
        if pygame.sprite.spritecollide(self,blocked_areas,False) :
            self.rect.x +=40
        if pygame.sprite.spritecollide(self,blocked_areas_enemy,True) :
            self.current_health -=10
            print(self.current_health)       
    def move_down(self) :
        if self.rect.y <=740 :
            self.rect.y +=40
        if pygame.sprite.spritecollide(self,blocked_areas,False) :
            self.rect.y -=40
        if pygame.sprite.spritecollide(self,blocked_areas_enemy,True) :
            self.current_health -=10
            print(self.current_health)       
    def move_up(self) :
        if self.rect.y > 0 :
            self.rect.y -=40
        if pygame.sprite.spritecollide(self,blocked_areas,False) :
            self.rect.y +=40
        if pygame.sprite.spritecollide(self,blocked_areas_enemy,True) :
            self.current_health -=10
            print(self.current_health)       