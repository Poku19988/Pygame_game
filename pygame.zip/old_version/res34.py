import pygame
pygame.init()
class button :
    def __init__(self,text,width,height,pos) :
        self.top_rect = pygame.Rect(pos,(width,height))
        self.top_color = '#475f77'
        self.text_surf = font.render(text,True,'#FFFFFF')
        self.text_rect = self.text_surf.get_rect(center = self.top_rect.center)
    def draw (self) :
        pygame.draw.rect(screen,self.top_color,self.top_rect)
        screen.blit(self.text_surf,self.text_rect)
screen = pygame.display.set_mode((800,600),0,32)
clock = pygame.time.Clock()

run = True
font = pygame.font.Font(None,30)
coor_x , coor_y = 300,100
button1 = button('fuckyou',450,250,(coor_x,coor_y))
button2 = button('Hi',450,250,(100,450))
b1_velocity = (1,1)
b2_velocity = (0.5,0.5)
while (run) :
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            break
        if event.type == pygame.KEYDOWN  :
            button1 = button('yu',450,250,(200,100)) 
            pygame.display.update()      
    screen.fill('#DCDDD8')
    if coor_x<700 and coor_y < 500 :
        coor_x += b1_velocity[0]/100
        coor_y +=b2_velocity[0]/100
    else :
            b1_velocity=(-1,-1)
            b2_velocity = (-1,-1)
            coor_x += b1_velocity[0]/100
            coor_y +=b2_velocity[0]/100
    button1 = button('fuck',450,250,(coor_x,coor_y)) 
    button2 = button('fuck',450,250,(coor_y,coor_x)) 
    button1.draw()
    button2.draw()
    pygame.display.update()
