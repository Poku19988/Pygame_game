import pygame
pygame.init()
screen = pygame.display.set_mode((800,400))
pygame.display.set_caption('reun')
char = pygame.image.load('coconut.png')
char_pos = 600
run = True
white = (255,255,255)
pygame.display.flip()
screen.blit(char,(char_pos,250))
screen.fill(white)
pygame.display.update()
while run == True :
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            break
        if event.type==pygame.KEYDOWN :
            char_pos+=1
            pygame.display.update()
    
    