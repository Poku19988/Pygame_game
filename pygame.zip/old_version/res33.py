import pygame
import random

pygame.init()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('reun')
char = pygame.image.load('coconut.png')
enemy_image = pygame.image.load('coconut.png')  # load enemy's image
char_pos = 600
run = True
white = (255,255,255)
black = (0,0,0)
oop = (222,22,122)
pygame.display.flip()
screen.blit(char,(char_pos,250))

for x in range(0, 800, 40):
    for y in range(0,800, 40):
        rect = pygame.Rect(x, y, 40, 40)
        pygame.draw.rect(screen, white, rect)
        pygame.draw.rect(screen, black, rect, 1)

class Player :
    def __init__(self,Level,Experience) :
        self.Health = 80 
        self.Level = Level 
        self.Experience = Experience

class Enemy:
    def __init__(self, screen, image, pos):
        self.screen = screen
        self.image = image
        self.pos = pos
        self.Health = 40

    def draw(self):
        self.screen.blit(self.image, self.pos)

class Healthbar :
    def __init__(self,Health,screen):
        self.Health = Health
        self.screen = screen
        self.maxHealth = 80

    def draw (self) :
        self.rect = pygame.Rect(600,40,160,40)
        self.rect2 = pygame.Rect(600,40,160,(self.Health/self.maxHealth)*160)
        pygame.draw.rect(self.screen,(52, 64, 235),self.rect)          
        pygame.draw.rect(self.screen,(240, 0, 24),self.rect2)

class Movement :  
    def __init__(self,screen,char,c) :
        self.screen = screen
        self.char = char
        self.init_pos = (0,0)
        self.c = c

    # ... keep the rest of your Movement class code here ...
    def move_right(self) :
        if self.init_pos[0] <760 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (255,255,255), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            self.init_pos =(self.init_pos[0]+40,self.init_pos[1])
            self.update_screen()
    def move_left(self) :
        if self.init_pos[0] >=40 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (255,255,255), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            self.init_pos =(self.init_pos[0]-40,self.init_pos[1])
            self.update_screen()
    def move_down(self) :
         if self.init_pos[1] < 740 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (255,255,255), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            self.init_pos =(self.init_pos[0],self.init_pos[1]+40)
            self.update_screen()
    def move_up(self) :
        if self.init_pos[1] >= 40 :
            rect = pygame.Rect(self.init_pos[0],self.init_pos[1], 40, 40)
            pygame.draw.rect(screen, (255,255,255), rect)
            pygame.draw.rect(screen, (0,0,0), rect, 1)
            self.init_pos =(self.init_pos[0],self.init_pos[1]-40)
            self.update_screen()
    def update_screen(self) :
        self.screen.blit(self.char,self.init_pos)  

c = True
health = Healthbar(90,screen)
movement = Movement(screen,char,c)  

# Create enemy
enemy = Enemy(screen, enemy_image, (random.randint(0, 760), random.randint(0, 740)))

while run == True :
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            run = False
        elif event.type == pygame.KEYDOWN :
            # ... keep the rest of your event handling code here ...
            if event.key == pygame.K_d :
                movement.move_right()
                movement.c = False
            if event.key == pygame.K_a :
                movement.move_left()
                movement.c = False
            if event.key == pygame.K_s :
                movement.move_down()
                movement.c = False
            if event.key == pygame.K_w :
                movement.move_up()
                movement.c =False
        elif movement.c == True:
            screen.blit(char,(0,0))

    health.draw()
    enemy.draw()  # Draw enemy

    # Check for collision with enemy
    if pygame.Rect(movement.init_pos[0], movement.init_pos[1], 40, 40).colliderect(pygame.Rect(enemy.pos[0], enemy.pos[1], 40, 40)):
        health.Health -= 10  # Decrease player health
        if health.Health <= 0:
            run = False  # Game over