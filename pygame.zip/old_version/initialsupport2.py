import pygame,random
pygame.init()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('Legend of theodora')
char = pygame.image.load('coconut.png')
spritesheet = pygame.image.load('char_spritesheet.png').convert_alpha()
background = pygame.image.load('map2.png')
enemy_image = 'coconut.png'
enemy_image2 = 'coconut.png'
run = True
white = (255,255,255)
black = (0,0,0)
frames = []
frames_d = []
collisions = pygame.sprite.Group()

for i in range(13) :
    x = i*32
    y = 0
    frame_rect = pygame.Rect(x, y , 32,32)
    frames.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
for i in range (10) :
    x = i*32
    y = 64
    frame_rect = pygame.Rect(x,y,32,32)
    if i%2 == 0 :
        frames_d.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
    else :
       frames_d.append(pygame.transform.flip((pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40))),True,False) )
class Player(pygame.sprite.Sprite) :
    def __init__(self,x,y) :
        super().__init__()
        self.frames = frames
        self.frames_d = frames_d
        self.image = self.frames[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.current_frame = 0
        self.frametimer = 0
        self.frame_delay = 19
        self.current = 0
    def upadate(self) :
        self.frametimer = pygame.time.get_ticks()
        if self.frametimer - self.current >= self.frame_delay :
            self.current_frame = (self.current_frame+1) % len(self.frames)
            self.image = self.frames[self.current_frame]
            self.frame_timer = 0
        self.current = pygame.time.get_ticks()
    def move_right(self) :
        if self.rect.x <=740 :
            self.rect.x +=40
    def move_left(self) :
        if self.rect.x >= 40 :
            self.rect.x -=40
    def move_down(self) :
        if self.rect.y <=740 :
            self.rect.y +=40
    def move_up(self) :
        if self.rect.y > 0 :
            self.rect.y -=40
    def attack(self) :
        self.frametimer = pygame.time.get_ticks()
        if self.frametimer - self.current >= 10 :
            self.current_frame = (self.current_frame+1) % len(self.frames_d)
            self.image = self.frames_d[self.current_frame]
            self.frame_timer = 0
        self.current = pygame.time.get_ticks()    
        
clock = pygame.time.Clock()
player = Player(0,0)
m_b = False
Menu_state = True
font = pygame.font.Font('freesansbold.ttf',36)
while Menu_state == True :
    screen.fill(white)
    Text = font.render('RPG SHIT',True,black)
    text_rect = Text.get_rect(center=(400, 400))
    screen.blit(Text, text_rect)
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.KEYDOWN :
            Menu_state = False
            screen.fill(black)
while run == True  :
    player.upadate()
    screen.blit(background,(0,0))
    screen.blit(player.image,player.rect)
    clock.tick(30)
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            run = False
        if event.type == pygame.KEYDOWN and event.key ==  pygame.K_d:
            player.move_right()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
            pygame.display.update()
        if event.type == pygame.KEYDOWN and event.key == pygame.K_a :
            player.move_left()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_s :
            player.move_down()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_w :
            player.move_up()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        if event.type == pygame.MOUSEBUTTONDOWN and  event.button == 1:
            for i in range(20) :
                player.attack()
                screen.blit(background,(0,0))
                screen.blit(player.image,player.rect)
                pygame.display.update()
                m_b =True
                time = pygame.time.get_ticks()
    for x in range(0, 800, 40):
        for y in range(0,800, 40):
            rect = pygame.Rect(x, y, 40, 40)
            pygame.draw.rect(screen, white, rect)
            pygame.draw.rect(screen, black, rect, 1)

    
