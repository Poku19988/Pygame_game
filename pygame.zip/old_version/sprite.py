import pygame
pygame.__init__()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('THE LEGEND OF THEODORA')
background = pygame.image.load('map2.png')
char_spritesheet = pygame.image.load('char_spritesheet')
enemy_spritesheet = pygame.image.load('Enemy_spritesheet.png') 
player_frames = [ char_spritesheet.subsurface((0,0,32,32))
,char_spritesheet.subsurface((32,0,32,32)),
char_spritesheet.subsurface((64,0,32,32)),
char_spritesheet.subsurface((96,0,32,32))    
]
enemy_frames = [enemy_spritesheet.subsurface((0,0,32,32)),
enemy_spritesheet.subsurface((32,0,32,32)),
enemy_spritesheet.subsurface((64,0,32,32)),
enemy_spritesheet.subsurface((96,0,32,32))
]
class player(pygame.sprite.Sprite) :
    def __init__(self,x,y) :
        super().__init__()
        self.x = x
        self.y = y
        self.last_update = pygame.time.get_ticks()
    def update(self) :
        self.now = pygame.time.get_ticks()
        if self.now - self.last_update <0.08 : #framerate 
            
