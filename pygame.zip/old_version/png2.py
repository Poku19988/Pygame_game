import pygame

pygame.init()
screen = pygame.display.set_mode((800,800))
pygame.display.set_caption('reun')

# Load spritesheet
spritesheet = pygame.image.load('spritesheet1.png').convert_alpha()

# Define animation frames
run_left_frames = [spritesheet.subsurface((0, 0, 100, 100)),
                   spritesheet.subsurface((100, 0, 100, 100)),
                   spritesheet.subsurface((200, 0, 100, 100)),
                   spritesheet.subsurface((300, 0, 100, 100)),
                   spritesheet.subsurface((400, 0, 100, 100))]

stand_frames = [spritesheet.subsurface((0, 100, 100, 100))]

# Define animation classes
class RunningLeft(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = run_left_frames
        self.index = 0
        self.image = self.frames[self.index]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.frame_rate = 100  # milliseconds per frame
        self.last_update = pygame.time.get_ticks()

    def update(self):
        # Update animation frame
        now = pygame.time.get_ticks()
        if now - self.last_update >= self.frame_rate:
            self.index = (self.index + 1) % len(self.frames)
            self.image = self.frames[self.index]
            self.last_update = now

class Standing(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.frames = stand_frames
        self.index = 0
        self.image = self.frames[self.index]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y

    def update(self):
        pass  # Standing animation doesn't need to update

# Create sprite groups
all_sprites = pygame.sprite.Group()
running_left_sprites = pygame.sprite.Group()
standing_sprites = pygame.sprite.Group()

# Create sprite instances and add them to sprite groups
running_left = RunningLeft(400, 400)
all_sprites.add(running_left)
running_left_sprites.add(running_left)

standing = Standing(400, 400)
all_sprites.add(standing)
standing_sprites.add(standing)

# Game loop
run = True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Update sprites
    running_left_sprites.update()
    standing_sprites.update()

    # Draw sprites
    screen.fill((255, 255, 255))
    all_sprites.draw(screen)

    pygame.display.flip()

pygame.quit()