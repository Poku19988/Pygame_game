import pygame
import random

# Initialize pygame
pygame.init()

# Set up the game window
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
game_window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Coconut Catcher")

# Set up the game clock
clock = pygame.time.Clock()

# Define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Define the player character
class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((50, 50))
        self.image.fill(WHITE)
        self.rect = self.image.get_rect()
        self.rect.centerx = WINDOW_WIDTH // 2
        self.rect.bottom = WINDOW_HEIGHT - 10
        self.speed = 5

    def update(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            self.rect.x -= self.speed
        if keys[pygame.K_RIGHT]:
            self.rect.x += self.speed
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WINDOW_WIDTH:
            self.rect.right = WINDOW_WIDTH

# Define the coconut object
class Coconut(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        self.image.fill((255, 200, 0))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.centery = y
        self.speed = random.randint(3, 10)

    def update(self):
        self.rect.y += self.speed

# Define the palm tree object
class PalmTree(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((80, 150))
        self.image.fill((0, 200, 0))
        self.rect = self.image.get_rect()
        self.rect.centerx = x
        self.rect.bottom = y

# Set up the game objects
player = Player()
coconuts = pygame.sprite.Group()
palm_trees = pygame.sprite.Group()

for i in range(5):
    palm_tree = PalmTree(random.randint(100, WINDOW_WIDTH - 100), random.randint(100, WINDOW_HEIGHT - 300))
    palm_trees.add(palm_tree)

# Set up the game loop
game_running = True
while game_running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_running = False

    # Update game objects
    player.update()
    coconuts.update()

    # Check for collisions between player and coconuts
    hits = pygame.sprite.spritecollide(player, coconuts, True)
    for hit in hits:
        print("Coconut caught!")

    # Check if coconuts have fallen off the screen
    for coconut in coconuts.copy():
        if coconut.rect.top > WINDOW_HEIGHT:
            coconut.kill()

    # Generate new coconuts at the top of each palm tree
    for palm_tree in palm_trees:
        if random.random() < 0.02:
            coconut = Coconut(palm_tree.rect.centerx, palm_tree.rect.top)
            coconuts.add(coconut)

    # Draw game objects
    game_window.fill(BLACK)
    palm_trees.draw(game_window)
    coconuts.draw(game_window)
    game_window.blit(player.image, player.rect)

    # Flip the display
    pygame.display.flip()

    # Set the game clock
    clock.tick(60)

# Quit pygame
pygame.quit()