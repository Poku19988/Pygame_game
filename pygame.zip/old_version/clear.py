import pygame,random
from UI import UI
from items import items
from player import Player
from enemy import Enemy
pygame.init()

screen = pygame.display.set_mode((800,800))
icon = pygame.image.load('gameicon.png')
pygame.display.set_caption('Legend of theodora')
pygame.display.set_icon(icon)
char = pygame.image.load('coconut.png')
spritesheet = pygame.image.load('char_spritesheet.png').convert_alpha()
enemy_spritesheet = pygame.image.load('Enemy_spritesheet.png')
background = pygame.image.load('map2.png')
sword_sound = pygame.mixer.Sound('sword.wav')
start_menu_sound = pygame.mixer.Sound('Startmenu.wav')
chest_pic = pygame.image.load('chest.png')
frames_a = []
frames = []
frames_d = []
spritesheet = pygame.image.load('char_spritesheet.png').convert_alpha()
for i in range(13) :
    x = i*32
    y = 0
    frame_rect = pygame.Rect(x, y , 32,32)
    frames.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
for i in range (10) :
    x = i*32
    y = 64
    frame_rect = pygame.Rect(x,y,32,32)
    frames_d.append(pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40)))
    frames_a.append(pygame.transform.flip((pygame.transform.scale(spritesheet.subsurface(frame_rect),(40,40))),True,False) )
run = True
white = (255,255,255)
black = (0,0,0)
current_health = 90
enemy_1 = Enemy(240,160)
player = Player(0,0,90)
clock = pygame.time.get_ticks()
bgrect = pygame.Rect(720,40,80,80)
font = pygame.font.Font('freesansbold.ttf',36)
ui = UI()
while Menu_state == True :    #Main Menu
    screen.fill(black)
    Text = font.render('RPG SHIT',True,white)
    text_rect = Text.get_rect(center=(400, 400))
    screen.blit(Text, text_rect)
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.KEYDOWN :
            Menu_state = False
            screen.fill(black)
while run == True  :           #Event handler
    current_mouse_pos = pygame.mouse.get_pos()
    player.upadate()
    enemy_1.upadate()
    clock.tick(10)
    screen.blit(background,(0,0))
    screen.blit(enemy_1.image,enemy_1.rect)
    screen.blit(player.image,player.rect)
    ui.show_bar(player.current_health,90,bgrect, (205,92,0))
    ui.show_exp(450)
    pygame.display.update()
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            pygame.quit()
            run = False
        if event.type == pygame.KEYDOWN and event.key ==  pygame.K_d:
            player.move_right()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_a :
            player.move_left()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_s :
            player.move_down()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        if event.type == pygame.KEYDOWN and event.key == pygame.K_w :
            player.move_up()
            screen.blit(background,(0,0))
            screen.blit(player.image,player.rect)
        next_mousepos = pygame.mouse.get_pos()
        if event.type == pygame.MOUSEBUTTONDOWN and  event.button == 1 and next_mousepos != current_mouse_pos :
            for i in range(20) :
                player.attack(next_mousepos,current_mouse_pos)
                screen.blit(background,(0,0))
                screen.blit(player.image,player.rect)
                screen.blit(enemy_1.image,enemy_1.rect)
                ui.show_bar(player.current_health,90,bgrect, (205,92,0))
                ui.show_exp(450)
                #sword_sound.play()
                pygame.display.update()
                m_b =True
                time = pygame.time.get_ticks()
    
