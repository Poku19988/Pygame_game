#physics program
import pygame
pygame.init()
screen = pygame.display.set_mode((300,300))
pygame.display.set_caption("Ball Physics")
ball_pos = [100,100]
ball_vel = [0,0]
ball_acc = [0,0.1]
white = (0,0,255)
running = True
clock = pygame.time.Clock()
while running :
    for event in pygame.event.get() :
        if event.type == pygame.QUIT :
            running = False
    ball_vel[0] += ball_acc[0]
    ball_vel[1] += ball_acc[1]
    ball_pos[0] += ball_vel[0]
    ball_pos[1] += ball_vel[1]
    screen.fill((white))
    pygame.draw.circle(screen,(255,255,255),ball_pos,10)
    pygame.display.flip()
    clock.tick(60)
pygame.QUIT

